import React from 'react'

export default function FunctionComponent(props) {
  return (
    <React.Fragment>
    <li>{props.nombre} traerá {props.tarea}</li>
    </React.Fragment>
  )
}





